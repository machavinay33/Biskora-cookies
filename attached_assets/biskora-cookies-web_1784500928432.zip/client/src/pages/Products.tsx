import { motion } from "framer-motion";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

interface Product {
  id: string;
  name: string;
  category: string;
  description: string;
  image: string;
  highlights: string[];
}

const products: Product[] = [
  {
    id: "1",
    name: "Desi Ghee Atta Cookies",
    category: "Traditional",
    description: "Rich, golden cookies made with pure desi ghee and whole wheat atta",
    image: "/manus-storage/biskora-desi-ghee-atta_f78eeb1e.png",
    highlights: ["Pure Ghee", "Whole Wheat", "No Refined Sugar"],
  },
  {
    id: "2",
    name: "Honey & Oats Cookies",
    category: "Healthy",
    description: "Wholesome cookies with natural honey and rolled oats",
    image: "/manus-storage/biskora-honey-oats_531f6ce8.png",
    highlights: ["Natural Honey", "Oats", "High Fiber"],
  },
  {
    id: "3",
    name: "Butter Cookies",
    category: "Classic",
    description: "Delicate, melt-in-mouth butter cookies with premium butter",
    image: "/manus-storage/biskora-butter-cookie.png",
    highlights: ["Premium Butter", "Delicate Texture", "Artisanal"],
  },
  {
    id: "4",
    name: "Elaichi Cookies",
    category: "Spiced",
    description: "Aromatic cookies infused with cardamom spice",
    image: "/manus-storage/biskora-elaichi-cookie_4b1a0f83.png",
    highlights: ["Cardamom", "Aromatic", "Traditional"],
  },
  {
    id: "5",
    name: "Ragi Biscuits",
    category: "Healthy",
    description: "Nutritious finger millet biscuits for health-conscious consumers",
    image: "/manus-storage/biskora-ragi-biscuit_6b4fd8c6.png",
    highlights: ["Finger Millet", "High Protein", "Gluten-Free"],
  },
  {
    id: "6",
    name: "Choco Vanilla Cookies",
    category: "Gourmet",
    description: "Premium chocolate and vanilla combination",
    image: "/manus-storage/biskora-choco-vanilla_e0fb6c33.png",
    highlights: ["Chocolate", "Vanilla", "Gourmet"],
  },
  {
    id: "7",
    name: "Coconut Cookies",
    category: "Tropical",
    description: "Tropical coconut cookies with a perfect crunch",
    image: "/manus-storage/biskora-coconut-cookie_4236e0d3.png",
    highlights: ["Fresh Coconut", "Crunchy", "Natural"],
  },
  {
    id: "8",
    name: "Dry Fruit Nut Cookies",
    category: "Premium",
    description: "Loaded with premium dry fruits and nuts",
    image: "/manus-storage/biskora-honey-oats_531f6ce8.png",
    highlights: ["Almonds", "Cashews", "Raisins"],
  },
  {
    id: "9",
    name: "Nan Khatai",
    category: "Traditional",
    description: "Traditional Indian shortbread cookies",
    image: "/manus-storage/biskora-desi-ghee-atta_f78eeb1e.png",
    highlights: ["Traditional", "Shortbread", "Authentic"],
  },
  {
    id: "10",
    name: "Ajwain Cookies",
    category: "Traditional",
    description: "Aromatic carom seed cookies with a savory twist",
    image: "/manus-storage/biskora-elaichi-cookie_4b1a0f83.png",
    highlights: ["Carom Seeds", "Savory", "Traditional"],
  },
  {
    id: "11",
    name: "Multigrain Cookies",
    category: "Healthy",
    description: "Nutritious blend of multiple grains and seeds",
    image: "/manus-storage/biskora-ragi-biscuit_6b4fd8c6.png",
    highlights: ["Multigrain", "Seeds", "High Fiber"],
  },
  {
    id: "12",
    name: "Almond Biscotti",
    category: "Premium",
    description: "Crispy Italian-style almond biscotti with premium almonds",
    image: "/manus-storage/biskora-honey-oats_531f6ce8.png",
    highlights: ["Almonds", "Crispy", "Premium"],
  },
  {
    id: "13",
    name: "Jaggery Cookies",
    category: "Healthy",
    description: "Naturally sweetened with jaggery, no refined sugar",
    image: "/manus-storage/biskora-desi-ghee-atta_f78eeb1e.png",
    highlights: ["Jaggery", "No Refined Sugar", "Natural"],
  },
  {
    id: "14",
    name: "Sesame Brittle Cookies",
    category: "Gourmet",
    description: "Crunchy sesame seeds with a brittle texture",
    image: "/manus-storage/biskora-choco-vanilla_e0fb6c33.png",
    highlights: ["Sesame", "Crunchy", "Gourmet"],
  },
  {
    id: "15",
    name: "Millet Chocolate Cookies",
    category: "Premium",
    description: "Wholesome millet combined with premium dark chocolate",
    image: "/manus-storage/biskora-coconut-cookie_4236e0d3.png",
    highlights: ["Millet", "Dark Chocolate", "Wholesome"],
  },
];

const categories = ["All", "Traditional", "Healthy", "Classic", "Spiced", "Gourmet", "Tropical", "Premium"];

export default function Products() {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredProducts =
    selectedCategory === "All"
      ? products
      : products.filter((p) => p.category === selectedCategory);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <div className="min-h-screen bg-background py-16 md:py-24">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-4">
            Our Cookie Collection
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover our carefully curated selection of premium cookies and dry cakes, each crafted with the finest ingredients and traditional techniques.
          </p>
        </motion.div>

        {/* Category Filters */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap gap-3 justify-center mb-12"
        >
          {categories.map((category) => (
            <Button
              key={category}
              onClick={() => setSelectedCategory(category)}
              variant={selectedCategory === category ? "default" : "outline"}
              className={`transition-all duration-300 ${
                selectedCategory === category
                  ? "bg-accent text-accent-foreground"
                  : "hover:border-accent"
              }`}
            >
              {category}
            </Button>
          ))}
        </motion.div>

        {/* Products Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {filteredProducts.map((product) => (
            <motion.div key={product.id} variants={itemVariants}>
              <Card className="h-full hover:shadow-lg transition-shadow duration-300 overflow-hidden group">
                <div className="relative overflow-hidden h-64 bg-muted">
                  <motion.img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    whileHover={{ scale: 1.1 }}
                  />
                </div>
                <CardHeader>
                  <CardTitle className="font-serif text-xl text-foreground">
                    {product.name}
                  </CardTitle>
                  <CardDescription className="text-sm text-muted-foreground">
                    {product.category}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{product.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {product.highlights.map((highlight) => (
                      <span
                        key={highlight}
                        className="inline-block px-3 py-1 bg-accent/10 text-accent text-xs rounded-full font-medium"
                      >
                        {highlight}
                      </span>
                    ))}
                  </div>
                  <Button
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground transition-all duration-300"
                    onClick={() => window.location.href = "/contact"}
                  >
                    Inquire Now
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
