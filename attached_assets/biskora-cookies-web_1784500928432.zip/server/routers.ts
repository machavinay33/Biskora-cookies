import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createContactInquiry } from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  contact: router({
    submit: publicProcedure
      .input(
        z.object({
          name: z.string().min(1).max(255),
          email: z.string().email(),
          phone: z.string().min(10).max(20),
          message: z.string().min(10).max(5000),
          orderType: z.string().min(1).max(100),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const inquiry = await createContactInquiry({
            name: input.name,
            email: input.email,
            phone: input.phone,
            message: input.message,
            orderType: input.orderType,
          });

          if (!inquiry) {
            throw new Error("Failed to create contact inquiry");
          }

          return {
            success: true,
            id: inquiry.id,
            message: "Thank you for your inquiry! We will get back to you soon.",
          };
        } catch (error) {
          console.error("[tRPC] Contact submission error:", error);
          throw new Error("Failed to submit contact inquiry");
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
