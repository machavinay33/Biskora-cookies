import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

describe("contact.submit", () => {
  const createPublicContext = (): TrpcContext => {
    return {
      user: null,
      req: {
        protocol: "https",
        headers: {},
      } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
  };

  it("should successfully submit a contact inquiry with valid data", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.contact.submit({
      name: "John Doe",
      email: "john@example.com",
      phone: "+919876543210",
      message: "I am interested in wholesale orders for my retail store.",
      orderType: "wholesale",
    });

    expect(result.success).toBe(true);
    expect(result.id).toBeDefined();
    expect(result.message).toContain("Thank you");
  });

  it("should reject submission with invalid email", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.contact.submit({
        name: "Jane Doe",
        email: "invalid-email",
        phone: "+919876543210",
        message: "I want to place a bulk order.",
        orderType: "bulk",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should reject submission with short message", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.contact.submit({
        name: "Bob Smith",
        email: "bob@example.com",
        phone: "+919876543210",
        message: "Short",
        orderType: "retail",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should reject submission with missing required fields", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.contact.submit({
        name: "",
        email: "test@example.com",
        phone: "+919876543210",
        message: "Test message for contact form submission",
        orderType: "contract",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should accept all valid order types", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const orderTypes = ["retail", "wholesale", "bulk", "contract", "private-label", "other"];

    for (const orderType of orderTypes) {
      const result = await caller.contact.submit({
        name: "Test User",
        email: `test-${orderType}@example.com`,
        phone: "+919876543210",
        message: `This is a test message for ${orderType} order type inquiry.`,
        orderType,
      });

      expect(result.success).toBe(true);
      expect(result.id).toBeDefined();
    }
  });
});
